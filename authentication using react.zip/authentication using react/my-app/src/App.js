import {Routes,Route,BrowserRouter} from "react-router-dom"
import './App.css';
import SignUp from "./components/SignUp"
import SignIn from "./components/SignIn"
import Home from "./components/Home"
function App() {

  return (
  <BrowserRouter>
  <Routes>
  <Route exact path="/" element={ <SignUp/>}/>
  <Route exact path="/signin" element={<SignIn/>}/>
  <Route exact path="/home" element={<Home/>}/>
  </Routes>
   
  </BrowserRouter>
    
   
   
  );
}

export default App;
