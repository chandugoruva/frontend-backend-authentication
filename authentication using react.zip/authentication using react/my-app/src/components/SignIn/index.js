import "./index.css"
import {useState} from "react"
import axios from "axios"
import md5 from "md5"
import {useNavigate} from "react-router-dom"
import Cookies from "js-cookie"
const SignIn=()=>{
    const [loginUsername,setUsername]=useState("")
    const [loginPassword,setPassword]=useState("")
    const [isError,setError]=useState(null)
    const [valid,setValid]=useState(false)
   const navigate=useNavigate();
  
    const onUsername=(event)=>{
        setUsername(event.target.value)
    }
    const onPassword=(event)=>{
        setPassword(event.target.value)
    }
    const onSignIn= async (event)=>{
        event.preventDefault()
        if(!loginUsername || !loginPassword){
            console.log("enter valid data")
            setValid(true)
        }   else{
            const loginHashedPassword= md5(loginPassword);
        console.log(loginHashedPassword)
        const userDetails={
            loginUsername,loginHashedPassword
        }
        const url="http://localhost:9000/Login"
       
        const response = await axios.post(url, userDetails);
        if(response.data.message==="login success"){
            navigate("/home")
            Cookies.set("myCookie",response.data.jwt,{expires:10})
        }
        else{
            setError(response.data)
        }
       
        console.log(response)
        }
    }
    
   return (
    <div className="signup-div">
        <div>
        <h1 className="signup-heading">SignIn</h1>
        <form  onSubmit={onSignIn}> 
            <label htmlFor="username" className="label">username: </label>
            <input type="text" id="username" className="input" onChange={onUsername}/>
           <br/>
            <label htmlFor="password" className="label">Password: </label>
            <input type="password" id="password" className="input" onChange={onPassword}/>
            <br/>
            <center>
            <button type="submit" className="signup-button">Login</button>
            {valid?<p className="error">please enter valid data</p>:null}
          <p className="error-msg">{isError}</p>
            </center>
           
        </form>
        </div>
   
    </div>
   
   )
}
export default SignIn