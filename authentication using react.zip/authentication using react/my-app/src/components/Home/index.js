import React from 'react';
import './index.css'; // Import your external CSS file

function Home() {
  return (
    <div className="home-div">
      <h1 className="home-heading">Welcome to Voltuswave</h1>
      <p className="home-paragraph">Inaugurated in 2017 by Charles Sasi Paul and Shammi Paul Charles, VoltusWave is an innovative Information Technology Startup hailing from Hyderabad. Positioned as an industry frontrunner, VoltusWave specializes in a no-code application development platform. Over the years, our cutting-edge platform has been the catalyst for a paradigm shift in the way organizations worldwide approach application development.</p>
    </div>
  );
}

export default Home;
