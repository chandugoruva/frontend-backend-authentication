import "./index.css"
import {useState} from "react"
import axios from "axios"
import md5 from "md5"
// import { useHistory } from 'react-router-dom'
import { useNavigate } from 'react-router-dom';
const SignUp=()=>{
    const [username,setUsername]=useState("")
    const [password,setPassword]=useState("")
    const [email,setEmail]=useState("")
    const [valid,setValid]=useState(false)
    const navigate=useNavigate()
    const [userexist,setUserExist]=useState(false)
    const onSignUp= async (event)=>{
        event.preventDefault()
        if(!username || !password ||  !email){
            console.log("enter valid data")
            setValid(true)
        }   
        else{
            setValid(false)
            const hashedPassword= md5(password);
        console.log(hashedPassword)
        const userDetails={
            username,email,hashedPassword
        }
        const url="http://localhost:9000/SignUp"
       
        const response = await axios.post(url, userDetails);
     
        console.log(response)
        
        if(response.data==="user already exist"){
          setUserExist(true)
        }
        else if(response.statusText==="OK"){
            console.log("successfully posted data")
            navigate("/signin")
        }
        
       
        
        }
        
       
    }
    const onUsername=(event)=>{
        setUsername(event.target.value)
    }
    const onEmail=(event)=>{
        setEmail(event.target.value)
    }
    const onPassword=(event)=>{
        setPassword(event.target.value)
    }
   return (
    <div className="signup-div">
        <div>
        <h1 className="signup-heading">SignUp</h1>
        <form onSubmit={onSignUp}>
            <label htmlFor="username" className="label">username: </label>
            <input type="text" id="username" className="input" onChange={onUsername}/>
            <br/>
            <label htmlFor="email" className="label">Email : </label>
            <input type="email" id="email" className="input-email" onChange={onEmail}/>
            <br/>
            <label htmlFor="password" className="label">Password: </label>
            <input type="password" id="password" className="input" onChange={onPassword}/>
            <br/>
            <center>
            <button type="submit" className="signup-button">SignUp</button>
            {valid?<p className="error">please enter valid data</p>:null}
            {userexist?<p>User name already exist</p>:null}
            </center>
           
        </form>
        </div>
   
    </div>
   
   )
}
export default SignUp